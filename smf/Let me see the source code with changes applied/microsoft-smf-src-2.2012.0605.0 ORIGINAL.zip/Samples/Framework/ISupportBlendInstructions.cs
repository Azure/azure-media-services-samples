﻿namespace Microsoft.SilverlightMediaFramework.Samples.Framework
{
    public interface ISupportBlendInstructions
    {
        string BlendInstructions { get; }
    }
}