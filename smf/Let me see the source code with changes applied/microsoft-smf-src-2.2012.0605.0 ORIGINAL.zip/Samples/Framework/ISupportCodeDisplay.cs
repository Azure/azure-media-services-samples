﻿namespace Microsoft.SilverlightMediaFramework.Samples.Framework
{
    public interface ISupportCodeDisplay
    {
        string CSharpCode { get; }
        string XamlCode { get; }
    }
}