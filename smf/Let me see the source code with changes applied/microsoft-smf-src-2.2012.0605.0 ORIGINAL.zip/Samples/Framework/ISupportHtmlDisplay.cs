﻿namespace Microsoft.SilverlightMediaFramework.Samples.Framework
{
    public interface ISupportHtmlDisplay
    {
        string HtmlCode { get; }
    }
}