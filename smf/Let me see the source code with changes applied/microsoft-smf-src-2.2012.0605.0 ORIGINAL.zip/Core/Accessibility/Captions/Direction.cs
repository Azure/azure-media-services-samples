﻿using System;

namespace Microsoft.SilverlightMediaFramework.Core.Accessibility.Captions
{
    public enum Direction
    {
        LeftToRight,
        RightToLeft
    }
}
