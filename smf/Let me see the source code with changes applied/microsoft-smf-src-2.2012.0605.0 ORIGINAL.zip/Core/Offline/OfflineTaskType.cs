﻿namespace Microsoft.SilverlightMediaFramework.Core.Offline
{
    public enum OfflineTaskType
    {
        DownloadFile = 0,
        ProcessManifest,
        QueueChunkList
    }
}