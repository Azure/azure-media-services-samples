namespace Microsoft.SilverlightMediaFramework.Core.TemplateDefinitions
{
    internal static class VolumeControlTemplateParts
    {
        internal const string SliderElement = "SliderElement";
        internal const string BaseElement = "BaseElement";
        internal const string ExpandingElement = "ExpandingElement";
    }
}
